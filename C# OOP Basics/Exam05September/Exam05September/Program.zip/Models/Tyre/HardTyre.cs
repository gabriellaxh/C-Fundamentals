﻿public class HardTyre : Tyre
{
    public HardTyre(double hardness) 
        : base(hardness)
    {
        base.Name = "Hard";
    }
}

