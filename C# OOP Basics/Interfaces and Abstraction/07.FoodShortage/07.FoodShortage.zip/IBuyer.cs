﻿public interface IBuyer
{
    string Name { get; set; }
    int Food { get; set; }
    int BuyFood();

}
