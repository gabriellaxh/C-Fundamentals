﻿using System.Collections.Generic;

public interface ILeutenantGeneral
{
    List<Private> Privates { get; set; }
}

