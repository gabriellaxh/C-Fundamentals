﻿public interface IAddCollection<T>
{
    int Add(T element);
}