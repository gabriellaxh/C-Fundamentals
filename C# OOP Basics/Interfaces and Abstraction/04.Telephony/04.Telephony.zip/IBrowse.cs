﻿using System.Collections.Generic;

public interface IBrowse
{
    List<string> Sites { get; set; }
}

