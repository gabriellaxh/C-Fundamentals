﻿using System.Collections.Generic;

public interface ICall
{
    List<string> PhoneNumbers { get; set; }
}

