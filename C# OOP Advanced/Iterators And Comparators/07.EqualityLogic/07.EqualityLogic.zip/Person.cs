﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.EqualityLogic
{
    public class Person : IComparable<Person>
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public Person(string name,int age)
        {
            this.Name = name;
            this.Age = age;
        }

        public int CompareTo(Person other)
        {
            int comparing = this.Name.CompareTo(other.Name);
            if (comparing == 0)
                comparing = this.Age.CompareTo(other.Age);

            return comparing;
        }

        public override bool Equals(object obj)
        {
            return this.Name.Equals(((Person)obj).Name) && this.Age.Equals(((Person)obj).Age);
        }

        public override int GetHashCode()
        {
            return this.Name.GetHashCode() + this.Age.GetHashCode();
        }
    }
}
