﻿namespace Logger.App.Models.Contracts
{
    public enum MessageLevel
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}