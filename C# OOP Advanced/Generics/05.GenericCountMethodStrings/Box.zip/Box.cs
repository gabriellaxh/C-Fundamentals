﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<T>
        where T : IComparable
    {
        private IComparable boxValue;

        public Box(IComparable value)
        {
            this.boxValue = value;
        }

        public int CountElements<Т>(List<IComparable> collection, Т element)
        {
            return collection.Count(x => x.CompareTo(element) > 0);
        }
    }
}
