﻿using _02.KingsGambit.Controllers;
using System;

namespace _02.KingsGambit
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
