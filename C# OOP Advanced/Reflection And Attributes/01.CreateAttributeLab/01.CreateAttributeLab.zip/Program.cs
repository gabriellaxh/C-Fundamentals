﻿using System;

[SoftUni("Ventsi")]

public class Program
{
    [SoftUni("Gosho")]
    static void Main(string[] args)
    {
    }
}

